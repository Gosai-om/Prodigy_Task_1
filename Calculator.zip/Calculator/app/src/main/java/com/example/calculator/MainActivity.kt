package com.example.calculator

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var tvExpression: TextView
    private lateinit var tvResult: TextView

    private var currentExpression = ""
    private var lastNumeric = false
    private var lastDot = false
    private var stateError = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvExpression = findViewById(R.id.ExpressionTv)
        tvResult = findViewById(R.id.ResultTv)
    }

    fun onDigitClick(view: View) {
        if (stateError) {
            tvExpression.text = (view as MaterialButton).text
            stateError = false
        } else {
            tvExpression.append((view as MaterialButton).text)
        }
        lastNumeric = true
    }

    fun onOperatorClick(view: View) {
        if (lastNumeric && !stateError) {
            tvExpression.append((view as MaterialButton).text)
            lastNumeric = false
            lastDot = false
        }
    }

    fun onClearClick(view: View) {
        tvExpression.text = ""
        tvResult.text = ""
        lastNumeric = false
        stateError = false
        lastDot = false
    }

    fun onBackClick(view: View) {
        val text = tvExpression.text.toString()
        if (text.isNotEmpty()) {
            tvExpression.text = text.dropLast(1)
        }
    }

    fun onEqualClick(view: View) {
        if (lastNumeric && !stateError) {
            val text = tvExpression.text.toString()
            try {
                val result = evaluate(text)
                tvResult.visibility = View.VISIBLE
                tvResult.text = result.toString()
            } catch (e: Exception) {
                tvResult.text = "Error"
                stateError = true
                lastNumeric = false
            }
        }
    }

    private fun evaluate(expression: String): Double {
        return object : Any() {
            var pos = -1
            var ch = 0

            fun nextChar() {
                ch = if (++pos < expression.length) expression[pos].code else -1
            }

            fun eat(charToEat: Int): Boolean {
                while (ch == ' '.code) nextChar()
                if (ch == charToEat) {
                    nextChar()
                    return true
                }
                return false
            }

            fun parse(): Double {
                nextChar()
                val x = parseExpression()
                if (pos < expression.length) throw RuntimeException("Unexpected: " + ch.toChar())
                return x
            }

            fun parseExpression(): Double {
                var x = parseTerm()
                while (true) {
                    when {
                        eat('\u002B'.code) -> x += parseTerm() // Unicode for +
                        eat('\u2212'.code) -> x -= parseTerm() // Unicode for -
                        else -> return x
                    }
                }
            }

            fun parseTerm(): Double {
                var x = parseFactor()
                while (true) {
                    when {
                        eat('\u00D7'.code) -> x *= parseFactor() // Unicode for ×
                        eat('\u00F7'.code) -> x /= parseFactor() // Unicode for ÷
                        else -> return x
                    }
                }
            }

            fun parseFactor(): Double {
                if (eat('\u002B'.code)) return parseFactor() // Unicode for +
                if (eat('\u2212'.code)) return -parseFactor() // Unicode for -


                var x: Double
                val startPos = pos
                if (eat('('.code)) {
                    x = parseExpression()
                    eat(')'.code)
                } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                    while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                    x = expression.substring(startPos, pos).toDouble()
                } else {
                    throw RuntimeException("Unexpected: " + ch.toChar())
                }
                //if (eat('\u0025'.code)) return parseFactor() / 100 // Unicode for %
                if (eat('\u0025'.code)) x /= 100 // Unicode for %

                return x
            }
        }.parse()
    }
}

